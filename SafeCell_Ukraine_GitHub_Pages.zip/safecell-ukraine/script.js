(() => {
  const menuButton = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav');
  if (menuButton && nav) {
    menuButton.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      menuButton.setAttribute('aria-expanded', String(isOpen));
      menuButton.textContent = isOpen ? '×' : '☰';
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      nav.classList.remove('open');
      menuButton.setAttribute('aria-expanded', 'false');
      menuButton.textContent = '☰';
    }));
  }

  const packageSelect = document.getElementById('package');
  const extraRange = document.getElementById('extra-cost');
  const extraValue = document.getElementById('extra-value');
  const siteCheck = document.getElementById('site-check');
  const calcTotal = document.getElementById('calc-total');
  const calcBreakdown = document.getElementById('calc-breakdown');
  const calcContact = document.getElementById('calc-contact');
  const money = value => new Intl.NumberFormat('uk-UA', { maximumFractionDigits: 0 }).format(value) + ' ₴';
  const packageName = value => ({'790000':'Base','1020000':'Comfort','1350000':'Plus'}[String(value)] || 'Comfort');

  function updateCalculator() {
    if (!packageSelect || !extraRange || !calcTotal) return;
    const base = Number(packageSelect.value);
    const pct = Number(extraRange.value);
    const survey = siteCheck && siteCheck.checked ? 25000 : 0;
    const reserve = Math.round(base * pct / 100);
    const total = base + reserve + survey;
    extraValue.textContent = pct + '%';
    calcTotal.textContent = money(total);
    calcBreakdown.textContent = `${money(base)} + ${pct}% резерву${survey ? ' + ' + money(survey) + ' умовного обстеження' : ''}`;
    if (calcContact) calcContact.href = 'contact.html?package=' + encodeURIComponent(packageName(base)) + '&estimate=' + encodeURIComponent(String(total));
  }
  [packageSelect, extraRange, siteCheck].forEach(el => el && el.addEventListener('input', updateCalculator));
  updateCalculator();

  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    const params = new URLSearchParams(window.location.search);
    const packageChoice = document.getElementById('package-choice');
    if (packageChoice && params.has('package')) {
      const requested = params.get('package');
      const option = Array.from(packageChoice.options).find(o => o.value.toLowerCase() === requested.toLowerCase());
      if (option) packageChoice.value = option.value;
    }
    const messageField = document.getElementById('message');
    if (messageField && params.has('estimate')) {
      messageField.value = 'Попередній демонстраційний розрахунок: ' + params.get('estimate') + ' грн. Прошу уточнити склад робіт і умови ділянки.';
    }
    contactForm.addEventListener('submit', event => {
      event.preventDefault();
      if (!contactForm.reportValidity()) return;
      const data = new FormData(contactForm);
      const subject = 'Запит щодо SafeCell — ' + (data.get('package') || 'консультація');
      const body = [
        'Ім’я: ' + data.get('name'),
        'Email для відповіді: ' + data.get('email'),
        'Комплектація: ' + data.get('package'),
        'Розташування ділянки: ' + (data.get('location') || 'не вказано'),
        '',
        'Повідомлення:',
        data.get('message') || 'не вказано',
        '',
        'Надіслано з навчального прототипу SafeCell.'
      ].join('\n');
      const mailto = 'mailto:viktoriaofficial20.12.06@gmail.com?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);
      const status = document.getElementById('form-status');
      if (status) status.textContent = 'Відкриваємо поштову програму. Перевірте чернетку та натисніть «Надіслати» у своїй програмі.';
      window.location.href = mailto;
    });
  }
})();